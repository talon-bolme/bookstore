/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author bramb
 */
public class GUIData {
    
    private static int ProductType;
    private static int SelectedProduct;
    private static int NumberOfCopies;
    private static String selectedProductName;
    private static double selectedProductPrice;
    private static double finalCost;
    private static int selectedProductInventory;

    public static int getSelectedProductInventory() {
        return selectedProductInventory;
    }

    public static void setSelectedProductInventory(int selectedProductInventory) {
        GUIData.selectedProductInventory = selectedProductInventory;
    }

    public static double getFinalCost() {
        return finalCost;
    }

    public static void setFinalCost(double finalCost) {
        GUIData.finalCost = finalCost;
    }

    public static String getSelectedProductName() {
        return selectedProductName;
    }

    public static void setSelectedProductName(String selectedProductName) {
        GUIData.selectedProductName = selectedProductName;
    }

    public static double getSelectedProductPrice() {
        return selectedProductPrice;
    }

    public static void setSelectedProductPrice(double selectedProductPrice) {
        GUIData.selectedProductPrice = selectedProductPrice;
    }

    public static int getProductType() {
        return ProductType;
    }

    public static void setProductType(String ProductType) {
        int intNum = Integer.parseInt(ProductType);
        GUIData.ProductType = intNum;
    }

    public static int getSelectedProduct() {
        return SelectedProduct;
    }

    public static void setSelectedProduct(String SelectedProduct) {
        int intNum = Integer.parseInt(SelectedProduct);
        GUIData.SelectedProduct = intNum;
    }

    public static int getNumberOfCopies() {
        return NumberOfCopies;
    }

    public static void setNumberOfCopies(String NumberOfCopies) {
        int intNum = Integer.parseInt(NumberOfCopies);
        GUIData.NumberOfCopies = intNum;
    }
    
}
