/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author Talon Bolme
 */
public abstract class Product {
    
    public int inventory;
    public double price;
    
    /**
     * 
     * @param invt
     * @param price 
     */
    public Product(int invt, double price) {
        this.inventory = invt;
        this.price = price;
    }
    
    /**
     * 
     * @return inventory
     */
    public int getInventory() {
        return inventory;
    }
    
    /**
     * 
     * @return price
     */
    public double getPrice() {
        return price;
    }
    
    /**
     * 
     * @param invt 
     */
    public void setInventory(int invt) {
        this.inventory = invt;
    }
    
    /**
     * Display info of object
     */
    public void display() {
        System.out.println("Name: Undefined | Type: Undefined");
        System.out.println("Inventory: " + inventory + " | Price: " + price);
    }
}
