/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author Talon Bolme
 */
public class Book extends Product {
    
    private String name;
    private int pageCount;
    private String author;
    
    public Book(int invt, double price, String author, String name, int pages) {
        super(invt, price);
        this.name = name;
        this.pageCount = pages;
        this.author = author;
    }
    
    public String getName() {
        return name;
    }
    
    public int getPageCount() {
        return pageCount;
    }
    
    public String getAuthor() {
        return author;
    }
    
    @Override
    public void display() {
        System.out.println("Name: " + name + " | Type: Book | Number of pages: " + pageCount);
        System.out.println("Inventory: " + inventory + " | Author: + " + author + " | Price: $" + price);
    }
    
}
