/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bolmetalonprogrammingckpt3;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.InputMismatchException;

/**
 *
 * @author Talon Bolme
 * Main bookstore program
 */
public class BookStore {
    Scanner fileScanner;
    static double dayEndPayment;
    static int dayEndCopiesSold;
    static String typeOfProductSold;
    
    /*
    Bookstore Constructor
    Scans CSV file to fill inventory
    */
    BookStore() throws FileNotFoundException {
        this.fileScanner = new Scanner(new File("C:/Users/bramb/Documents/NetBeansProjects/BolmeTalonProgrammingCkpt2/src/bolmetalonprogrammingckpt3/BookstoreInventoryDay1.csv"));
        String line;
        while (fileScanner.hasNext()) {
            line = fileScanner.nextLine();
            String[] inventoryData = line.split(",");
            String bookTest = "book";
            String cdTest = "cd";
            String dvdTest = "dvd";
            
            //Parse through the file & test which type of product is being represented
            if (bookTest.equals(inventoryData[1])) {
                int intOne = parseInt(inventoryData[4]);
                int intTwo = parseInt(inventoryData[6]);
                double doubleOne = parseDouble(inventoryData[5]);
                bookList.add(new Book(intOne, doubleOne, inventoryData[3], inventoryData[2], intTwo));
            } else if (cdTest.equals(inventoryData[1])) {
                int intOne = parseInt(inventoryData[4]);
                int intTwo = parseInt(inventoryData[6]);
                double doubleOne = parseDouble(inventoryData[5]);
                cdList.add(new CD(intOne, doubleOne, inventoryData[3], inventoryData[2], intTwo));
            } else if (dvdTest.equals(inventoryData[1])) {
                int intOne = parseInt(inventoryData[4]);
                double doubleOne = parseDouble(inventoryData[5]);
                double doubleTwo = parseDouble(inventoryData[6]);
                dvdList.add(new DVD(intOne, doubleOne, inventoryData[3], inventoryData[2], doubleTwo));
            }
        }
        //bookList.add(new Book(3, 7.99, "e", "War and Peace", 589));
        //bookList.add(new Book(4, 9.99, "e", "Twillight", 265));
        //cdList.add(new CD(2, 11.99, "e", "Scars", 13));
        //dvdList.add(new DVD(4, 14.99, "e", "Inception", 2.5));
        
        
    }
    
    //Create ArrayLists
    private ArrayList<Product> productList = new ArrayList();
    private ArrayList<Book> bookList = new ArrayList();
    private ArrayList<CD> cdList = new ArrayList();
    private ArrayList<DVD> dvdList = new ArrayList();
    private ArrayList<Product> memberInventory = new ArrayList();
    Scanner sc = new Scanner(System.in);
    
    /**
     * Method to convert string to double
     * @param string
     * @return doubleNum
     * @throws NumberFormatException 
     */
    public static double parseDouble(String string) throws NumberFormatException {
        double doubleNum = Double.parseDouble(string);
        return doubleNum;
    }
    
    /**
     * Method to convert string to int
     * @param string
     * @return doubleNum
     * @throws NumberFormatException 
     */
    public static int parseInt(String string) throws NumberFormatException {
        int intNum = Integer.parseInt(string);
        return intNum;
    }
    
    /**
     * Method for becoming a member
     * @param newMember 
     */
    public void becomeMember(RegularMember newMember){
        newMember.member = true;
    }
    
    /**
     * Method for becoming a new premium member
     * @param newPMember 
     */
    public void becomePremiumMember(PremiumMember newPMember){
        newPMember.premiumMember = true;
    }
    
    /**
     * Method for removing current premium member
     * @param newPMember 
     */
    public void removePremiumMember(PremiumMember newPMember) {
        newPMember.premiumMember = false;
    }
    
    /**
     * Method for resetting DayEndPayment
     * @param input 
     */
    public static void setDayEndPayment(double input) {
        dayEndPayment = input;
    }
    
    /**
     * Method for resetting dayEndCopiesSold
     * @param input 
     */
    public static void setDayEndCopiesSold(int input) {
        dayEndCopiesSold = input;
    }
    
    /**
     * Method for resetting typeOfProductSold
     * @param input 
     */
    public static void setTypeOfProductSold(String input) {
        typeOfProductSold = input;
    }
    
    /**
     * Method to complete a purchase
     * @return cost
     * @throws IOException 
     */
    public double completePurchase() throws IOException {
        System.out.println("What type of item do you want to purchase?");
        System.out.println("1. Book | 2. CD | 3. DVD | 4. None");
        int num;
        int num2;
        int num3;
        int num21;
        int num22;
        int num23;
        int num31;
        int num32;
        int num33;
        num = sc.nextInt();
        switch (num) {
            case 1:
                System.out.println("Books we currently have in stock:");
                int listSize = bookList.size();
                int a;
                for (a = 0; a < listSize; a++) {
                    Book currentBook = bookList.get(a);
                    System.out.print((a+1) + ". ");
                    currentBook.display();
                    System.out.println("");
                }
                System.out.println("What book do you want to purchase?");
                try {
                num2 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num2 > listSize || num2 < 1) {
                    System.out.println("Error! That's not a viable option.");
                    break;
                }                
                Book selectedBook = bookList.get(num2-1);
                System.out.println("How many copies do you want to purchase?");
                try {
                num2 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num2 > selectedBook.getInventory()) {
                    System.out.println("Error! We don't have that many in stock.");
                    break;
                }
                if (num2 < 1) {
                    System.out.println("Error! Please select a real amount.");
                    break;
                }
                double cost = (selectedBook.getPrice()*num2);
                System.out.println("Your cost is : $" + cost + ". Is this okay?");
                System.out.println("1. Yes | 2. No");
                try {
                num3 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num3 == 1) {
                    int inventory = selectedBook.getInventory();
                    selectedBook.setInventory(inventory - num2);
                    System.out.println("Purchase complete! You have spent " + cost + " on " 
                    + num2 + " copies of " + selectedBook.getName());
                }
                dayEndPayment = cost;
                dayEndCopiesSold = num2;
                typeOfProductSold = "book";
                return cost;
            case 2:
                System.out.println("CDs we currently have in stock:");
                int listSize2 = cdList.size();
                int b;
                for (b = 0; b < listSize2; b++) {
                    CD currentCD = cdList.get(b);
                    System.out.print((b+1) + ". ");
                    currentCD.display();
                    System.out.println("");
                }
                System.out.println("What CD do you want to purchase?");
                try {
                num21 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num21 > listSize2 || num21 < 1) {
                    System.out.println("Error! That's not a viable option.");
                    break;
                }    
                CD selectedCD = cdList.get(num21-1);
                System.out.println("How many copies do you want to purchase?");
                try {
                num22 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num22 > selectedCD.getInventory()) {
                    System.out.println("Error! We don't have that many in stock.");
                    break;
                }
                if (num22 < 1) {
                    System.out.println("Error! Please select a real amount.");
                    break;
                }
                double cost2 = (selectedCD.getPrice()*num22);
                System.out.println("Your cost is : $" + cost2 + ". Is this okay?");
                System.out.println("1. Yes | 2. No");
                try {
                num23 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num23 == 1) {
                    int inventory2 = selectedCD.getInventory();
                    selectedCD.setInventory(inventory2 - num22);
                    System.out.println("Purchase complete! You have spent " + cost2 + " on " 
                    + num22 + " copies of " + selectedCD.getName());
                }
                dayEndPayment = cost2;
                dayEndCopiesSold = num22;
                typeOfProductSold = "cd";
                return cost2;
            case 3:
                System.out.println("DVDs we currently have in stock:");
                int listSize3 = dvdList.size();
                int c;
                for (c = 0; c < listSize3; c++) {
                    DVD currentDVD = dvdList.get(c);
                    System.out.print((c+1) + ". ");
                    currentDVD.display();
                    System.out.println("");
                }
                System.out.println("What DVD do you want to purchase?");
                try {
                num31 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num31 > listSize3 || num31 < 1) {
                    System.out.println("Error! That's not a viable option.");
                    break;
                }    
                DVD selectedDVD = dvdList.get(num31-1);
                System.out.println("How many copies do you want to purchase?");
                try {
                num32 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num32 > selectedDVD.getInventory()) {
                    System.out.println("Error! We don't have that many in stock.");
                    break;
                }
                if (num32 < 1) {
                    System.out.println("Error! Please select a real amount.");
                    break;
                }
                double cost3 = (selectedDVD.getPrice()*num32);
                System.out.println("Your cost is : $" + cost3 + ". Is this okay?");
                System.out.println("1. Yes | 2. No");
                try {
                num33 = sc.nextInt();
                } catch (InputMismatchException ex) {
                    System.out.println("Error! Input did not register correctly.");
                    break;
                } catch (Exception ex) {
                    System.out.println("Error! Exiting purchase cycle.");
                    break;
                }
                if (num33 == 1) {
                    int inventory3 = selectedDVD.getInventory();
                    selectedDVD.setInventory(inventory3 - num32);
                    System.out.println("Purchase complete! You have spent $" + cost3 + " on " 
                    + num32 + " copies of " + selectedDVD.getName());
                }
                dayEndPayment = cost3;
                dayEndCopiesSold = num32;
                typeOfProductSold = "dvd";
                return cost3;
            case 4:
                break;
            default:
                System.out.println("Sorry, but you need to enter a 1, 2, 3 or a 4");
        }
        
                
          return 0;      
        }
    
    /**
     * Writing day results to a .txt file
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public void writeDayResults() throws FileNotFoundException, IOException {
        try {
        FileOutputStream fs = new FileOutputStream("C:/Users/bramb/Documents/NetBeansProjects/BolmeTalonProgrammingCkpt2/src/bolmetalonprogrammingckpt2/EndOfDayReport.txt");
        PrintWriter outFS = new PrintWriter(fs);
        outFS.println("End of Day Results:");
        outFS.println("Type of Product Sold: " + typeOfProductSold);
        outFS.println("Number of Copies Sold: " + dayEndCopiesSold);
        outFS.println("New Members Today: " + ProgrammingCkpt2Test.isNewMemberToday());
        outFS.println("New Premium Members Today: " + ProgrammingCkpt2Test.isNewPremiumMemberToday());
        outFS.println("Revenue Today: " + dayEndPayment);
        outFS.println("Total Revenue Made: " + ProgrammingCkpt2Test.getTotalCost());
        outFS.close();
        fs.close();
        } catch (FileNotFoundException ex) {
            return;
        } catch (Exception e) {
            return;
        }
        
    }
    
    /**
     * Writes updated inventory to another .csv file
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public void updateBookstoreInventory() throws FileNotFoundException, IOException {
        try {
        FileOutputStream fs = new FileOutputStream("C:/Users/bramb/Documents/NetBeansProjects/BolmeTalonProgrammingCkpt2/src/bolmetalonprogrammingckpt2/BookstoreInventoryUpdated.csv");
        PrintWriter outFS = new PrintWriter(fs);
        int d;
        int listSize = bookList.size();
        int listSize2 = cdList.size();
        int listSize3 = dvdList.size();
        for (d = 0; d < listSize; d++) {
            Book currentBook = bookList.get(d);
            outFS.print(d+1 + ",");
            outFS.print("book,");
            outFS.print(currentBook.getName() + ",");
            outFS.print(currentBook.getAuthor() + ",");
            outFS.print(currentBook.getInventory() + ",");
            outFS.print(currentBook.getPrice() + ",");
            outFS.print(currentBook.getPageCount());
            outFS.println();
        }
        for (d = 0; d < listSize2; d++) {
            CD currentCD = cdList.get(d);
            outFS.print((d+1+listSize) + ",");
            outFS.print("cd,");
            outFS.print(currentCD.getName() + ",");
            outFS.print(currentCD.getArtist() + ",");
            outFS.print(currentCD.getInventory() + ",");
            outFS.print(currentCD.getPrice() + ",");
            outFS.print(currentCD.getTrackList()); 
            outFS.println();
        }
        for (d = 0; d < listSize3; d++) {
            DVD currentDVD = dvdList.get(d);
            outFS.print((d+1+listSize+listSize2) + ",");
            outFS.print("dvd,");
            outFS.print(currentDVD.getName() + ",");
            outFS.print(currentDVD.getDirector() + ",");
            outFS.print(currentDVD.getInventory() + ",");
            outFS.print(currentDVD.getPrice() + ",");
            outFS.print(currentDVD.getDuration()); 
            outFS.println();
        }
        outFS.close();
        fs.close();
        } catch (FileNotFoundException ex) {
            return;
        } catch (Exception e) {
            return;
        }
        
    }
    
    /**
     * Displays information
     */
    public void display() {
        int d;
        int listSize = bookList.size();
        for (d = 0; d < listSize; d++) {
            Book currentBook = bookList.get(d);
            System.out.print("Book " + (d+1) + ": ");
            currentBook.display();
            System.out.println("");                    
        }
        int listSize2 = cdList.size();
        for (d = 0; d < listSize2; d++) {
                    CD currentCD = cdList.get(d);
                    System.out.print("CD " + (d+1) + ": ");
                    currentCD.display();
                    System.out.println("");
                }
        int listSize3 = dvdList.size();
        for (d = 0; d < listSize3; d++) {
                    DVD currentDVD = dvdList.get(d);
                    System.out.print("DVD " + (d+1) + ": ");
                    currentDVD.display();
                    System.out.println("");
                }
        
                        
    }
    
    
    
}
