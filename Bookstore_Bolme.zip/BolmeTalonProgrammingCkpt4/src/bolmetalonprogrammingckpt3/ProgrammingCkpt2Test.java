/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.lang.Math;

/**
 * Full test file for the Programming Checkpoint project
 * @author Talon Bolme
 */
public class ProgrammingCkpt2Test {
    
    static double totalCost = 0;
    static int newMemberToday;
    static int newPremiumMemberToday;
    
    /**
     * Gets the total cost
     * @return finalCost
     */
    public static double getTotalCost() {
        double finalCost = totalCost;
        return finalCost;
    }
    
    /** 
     * Checks if there was a new member added during that business day
     * @return newMemberToday
     */
    public static int isNewMemberToday() {
        return newMemberToday;
    }
    /**
     * Checks if there was a new premium member added during that business day
     * @return newPremiumMemberToday
     */
    public static int isNewPremiumMemberToday() {
        return newPremiumMemberToday;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        BookStore store = new BookStore();
        Scanner sc = new Scanner(System.in);
        int weeks = 0;
        int programEnd = 1;
        int a = 0;
        int weeksMissedPayment = 0;
        int weeksPremiumMember = 0;
        int weeksPremiumCost = 0;
        PremiumMember memberP1 = new PremiumMember();
        
        StoreStartFrame firstFrame = new StoreStartFrame();
        firstFrame.setVisible(true);
        
//        while (programEnd > 0) {
//            weeks++;
//            System.out.println("------------------");
//            if(a<0) {
//                System.out.println("WARNING: Your payment is overdue! You need to pay for " + Math.abs(a) + " months!");
//                weeksMissedPayment++;
//            }
//            if(memberP1.premiumMember) {
//                weeksPremiumMember++;
//                weeksPremiumCost++;
//                if(weeksPremiumMember%30 == 0) {
//                    a--;
//                }
//            }            
//            System.out.println("Welcome to the Bookstore! This is day #" + weeks);
//            if(memberP1.premiumMember) {
//                System.out.println("Days left until payment is due: " + (30-weeksPremiumMember));
//                if (weeksPremiumMember == 30) {
//                    System.out.println("Pay your membership fee now!");
//                    weeksPremiumMember = 0;
//                }
//                //if (weeksPremiumMember == 1) {
//                  //  System.out.println("Weeks left until payment is due: 3");
//                //} else if (weeksPremiumMember == 2) {
//                  //  System.out.println("Weeks left until payment is due: 2");
//                //} else if (weeksPremiumMember == 3) {
//                  //  System.out.println("Weeks left until payment is due: 1");
//                //} else {
//                  //  System.out.println("Weeks left until payment is due: 0");
//                    //System.out.println("Pay your membership fee now!");
//                    //weeksPremiumMember = 0;
//             //   } 
//            }
//            
//            
//            System.out.println("Please select one of the following: ");
//            if(memberP1.premiumMember) {
//                System.out.println("\t 0: Make Premium Membership Payment");
//            }
//            System.out.println("\t 1. Manage Membership");
//            System.out.println("\t 2. Complete a Purchase");
//            System.out.println("\t 3. Check Store Inventory");
//            System.out.println("\t 4. Do Nothing");
//            System.out.println("\t 5. Check How Much You'"
//                    + "ve Payed");
//            System.out.println("\t 6. End Program");
//            
//            int num = sc.nextInt();
//            int num2;
//            switch (num) {
//                case 0: 
//                    System.out.println("You are about to pay for 1 month of your membership. Proeced?");
//                    System.out.println("1. Yes | 2. No");
//                    num2 = sc.nextInt();
//                    if (num2 == 1) {
//                        System.out.println("You have paid for 1 month of your membership");
//                        totalCost = totalCost + 9.99;
//                        a++;
//                        store.writeDayResults();
//                        break;
//                    }
//                    store.writeDayResults();
//                    break;
//                case 1:
//                    if (PremiumMember.premiumMember) {
//                        System.out.println("You are currently a premium member. Would you like to cancel your membership?");
//                        System.out.println("1. Yes | 2. No");
//                        num2 = sc.nextInt();
//                        if (num2 == 1) {
//                            store.removePremiumMember(memberP1);
//                            System.out.println("You have now been removed as a premium member.");
//                            BookStore.setDayEndPayment(0);
//                            BookStore.setDayEndCopiesSold(0);
//                            BookStore.setTypeOfProductSold("None");
//                            store.writeDayResults();
//                            break;
//                        } else {
//                            BookStore.setDayEndPayment(0);
//                            BookStore.setDayEndCopiesSold(0);
//                            BookStore.setTypeOfProductSold("None");
//                            store.writeDayResults();
//                            break;
//                        }
//                    }
//                    if (!PremiumMember.premiumMember) {
//                        if (RegularMember.member) {
//                            System.out.println("You are currently a member of the store. "
//                                    + "Would you like to become a Premium member? Only $9.99 per month!");
//                            System.out.println("1. Yes | 2. No");
//                            num2 = sc.nextInt();
//                              if (num2 == 1) {
//                                memberP1.setPrice(9.99);
//                                store.becomePremiumMember(memberP1);
//                                System.out.println("Congratulations! You are now a premium member of the bookstore!");
//                                newPremiumMemberToday = 1;
//                                 BookStore.setDayEndPayment(0);
//                                 BookStore.setDayEndCopiesSold(0);
//                                 BookStore.setTypeOfProductSold("None");
//                                store.writeDayResults();
//                                newPremiumMemberToday = 0;
//                                break;
//                            } else {
//                                BookStore.setDayEndPayment(0);
//                                BookStore.setDayEndCopiesSold(0);
//                                BookStore.setTypeOfProductSold("None");  
//                                store.writeDayResults();  
//                                break;
//                            }                            
//                        }
//                        if (!RegularMember.member) {
//                            System.out.println("You are not a member yet! Would you like to become one? (It's free)");
//                            System.out.println("1. Yes | 2. No");
//                            num2 = sc.nextInt();
//                            if (num2 == 1) {
//                                RegularMember member1 = new RegularMember();
//                                store.becomeMember(member1);
//                                System.out.println("Congratulations! You are now a member of the bookstore!");
//                                newMemberToday = 1;
//                                store.writeDayResults();
//                                newMemberToday = 0;
//                                break;
//                            } else {
//                                store.writeDayResults();
//                                break;
//                            }
//                        }
//                    }
//                case 2:
//                    double newCost = store.completePurchase();
//                    totalCost = totalCost + newCost;
//                    store.writeDayResults();
//                    store.updateBookstoreInventory();
//                    break;
//                case 3: 
//                    store.display();
//                    BookStore.setDayEndPayment(0);
//                    BookStore.setDayEndCopiesSold(0);
//                    BookStore.setTypeOfProductSold("None");
//                    store.writeDayResults();
//                    break;
//                case 4:
//                    BookStore.setDayEndPayment(0);
//                    BookStore.setDayEndCopiesSold(0);
//                    BookStore.setTypeOfProductSold("None");
//                    store.writeDayResults();
//                    break;
//                case 5:
//                    System.out.println("You have spent $" + totalCost + " at this store.");
//                    BookStore.setDayEndPayment(0);
//                    BookStore.setDayEndCopiesSold(0);
//                    BookStore.setTypeOfProductSold("None");
//                    store.writeDayResults();
//                    break;
//                case 6:
//                    programEnd--;
//                    BookStore.setDayEndPayment(0);
//                    BookStore.setDayEndCopiesSold(0);
//                    BookStore.setTypeOfProductSold("None");
//                    store.writeDayResults();
//                    store.updateBookstoreInventory();
//                    break;
//                default:
//                    if (PremiumMember.premiumMember) {
//                        System.out.println("Sorry, you must choose a number 0-6");
//                        BookStore.setDayEndPayment(0);
//                        BookStore.setDayEndCopiesSold(0);
//                        BookStore.setTypeOfProductSold("None");
//                        store.writeDayResults();
//                        break;
//                    }
//                    System.out.println("Sorry, you must choose a number 1-6");
//                    BookStore.setDayEndPayment(0);
//                    BookStore.setDayEndCopiesSold(0);
//                    BookStore.setTypeOfProductSold("None");
//                    store.writeDayResults();
//                    break;
//                }
//            }
        }

    //static String isNewMemberToday() {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
        
    }
    

