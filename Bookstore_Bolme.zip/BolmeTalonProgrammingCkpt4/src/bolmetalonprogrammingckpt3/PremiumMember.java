/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author Talon Bolme
 */
public class PremiumMember extends RegularMember {
    
    protected int weeksPremiumMember;
    public static boolean premiumMember = false;
    public double price;
    
    public PremiumMember() {
        super();
    }
    
    public int getWeeksPremiumMember() {
        return weeksPremiumMember;
    }
    
    public boolean isUserPremiumMember() {
        return premiumMember;
    }
    
    public void setUserPremiumMember(boolean set) {
        this.premiumMember = set;
    }
    
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public double getPrice() {
        return price;
    }
    
}
