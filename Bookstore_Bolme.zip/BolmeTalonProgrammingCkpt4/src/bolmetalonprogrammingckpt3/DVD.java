/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author Talon Bolme
 */
public class DVD extends Product {
    
    private String name;
    private double duration;
    private String director;
    
    public DVD(int invt, double price, String director, String name, double duration) {
        super(invt, price);
        this.name = name;
        this.duration = duration;
    }
    
    public String getName() {
        return name;
    }
    
    public double getDuration() {
        return duration;
    }
    
    public String getDirector() {
        return director;
    }
    
    @Override
    public void display() {
        System.out.println("Name: " + name + " | Type: DVD | Duration: " + duration + " hours");
        System.out.println("Inventory: " + inventory + " | Director: " + director + " | Price: $" + price);
    }
    
    
}
