/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author Talon Bolme
 */
public class CD extends Product{
    
    private String name;
    private int trackList;
    private String artist;
    
    public CD(int invt, double price, String artist, String name, int tracks) {
        super(invt, price);
        this.name = name;
        this.trackList = tracks;
        this.artist = artist;
    }
    
    public String getName() {
        return name;
    }
    
    public int getTrackList() {
        return trackList;
    }
    
    public String getArtist() {
        return artist;
    }
    
    @Override
    public void display() {
        System.out.println("Name: " + name + " | Type: CD | Number of Tracks: " + trackList);
        System.out.println("Inventory: " + inventory + " | Artist: " + artist + " | Price: $" + price);
    }
    
    
}
