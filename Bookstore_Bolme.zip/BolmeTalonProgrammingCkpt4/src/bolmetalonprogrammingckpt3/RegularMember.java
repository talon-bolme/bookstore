/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bolmetalonprogrammingckpt3;

/**
 *
 * @author Talon Bolme
 */
public class RegularMember {
    
    public int weeksMember;
    public static boolean member = false;
    public RegularMember() {
        
    }
    
    public int getWeeksMember() {
        return weeksMember;
    }
    
    public boolean isUserMember() {
        return member;
    }
    
    public void setUserMember(boolean set) {
        this.member = set;
    }
    
    
    
}
